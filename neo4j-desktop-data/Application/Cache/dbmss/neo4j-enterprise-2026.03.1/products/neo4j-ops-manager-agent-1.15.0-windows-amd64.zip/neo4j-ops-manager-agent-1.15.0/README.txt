Neo4j Ops Manager Agent 1.15.0
=======================================

Welcome to Neo4j Ops Manager Agent release 1.15.0.

In the box
----------

Neo4j Ops Manager Agent runs as a server application, that collects information from locally
running Neo4j instances and sends them to the configured Neo4j Ops Manager Server.

Here in the installation directory, you'll find:

* bin - scripts and/or executables
* logs - log files

Make it go
----------

For full instructions, see https://neo4j.com/docs

License(s)
----------
Various licenses apply. Please refer to the LICENSE and NOTICE files for more
detailed information.
